import "./modulepreload-polyfill-7faf532e.js";
chrome.devtools.panels.create(
  "AM-Knight",
  "icon.png",
  "devtools-panel.html",
  function(panel) {
  }
);
//# sourceMappingURL=devtools-0900c8d7.js.map
