(function(){var _a;
function normalizeText(text) {
  if (!text)
    return "";
  let res = text.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  res = res.replace(/0/g, "o").replace(/1/g, "i").replace(/3/g, "e").replace(/4/g, "a").replace(/@/g, "a").replace(/5/g, "s").replace(/7/g, "t").replace(/\$/g, "s");
  res = res.replace(/([a-z])!+([a-z])/g, "$1i$2");
  return res.replace(/[^a-z0-9 ]/gi, " ").replace(/\s+/g, " ").trim();
}
function levenshteinDistance(a, b) {
  if (a.length === 0)
    return b.length;
  if (b.length === 0)
    return a.length;
  const matrix = [];
  for (let i = 0; i <= b.length; i++)
    matrix[i] = [i];
  for (let j = 0; j <= a.length; j++)
    matrix[0][j] = j;
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1))
        matrix[i][j] = matrix[i - 1][j - 1];
      else
        matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, Math.min(matrix[i][j - 1] + 1, matrix[i - 1][j] + 1));
    }
  }
  return matrix[b.length][a.length];
}
function fuzzyCheck(message, ahoCorasick, bloomFilter, badWords, whitelist = []) {
  if (!message)
    return null;
  const normalizedMsg = normalizeText(message);
  if (ahoCorasick) {
    const results = ahoCorasick.search(normalizedMsg);
    if (results.length > 0) {
      const validResults = results.filter((r) => {
        const start2 = r.index;
        const end = start2 + r.word.length;
        const leftBoundary = start2 === 0 || normalizedMsg[start2 - 1] === " ";
        const rightBoundary = end === normalizedMsg.length || normalizedMsg[end] === " ";
        return leftBoundary && rightBoundary && whitelist.indexOf(r.word) === -1;
      });
      if (validResults.length > 0) {
        return { type: "MOT_INTERDIT", found: validResults[0].word, trigger: validResults[0].word };
      }
    }
  }
  const words = normalizedMsg.split(" ");
  for (let m = 0; m < words.length; m++) {
    const mw = words[m];
    if (mw.length < 3)
      continue;
    if (whitelist.indexOf(mw) !== -1)
      continue;
    for (let k = 0; k < badWords.length; k++) {
      const bw = normalizeText(badWords[k]);
      if (mw === bw)
        return { type: "FUZZY_EXACT", trigger: badWords[k], found: mw };
      if (bw.length < 6 || mw.length < 6)
        continue;
      if (Math.abs(mw.length - bw.length) <= 2) {
        const dist = levenshteinDistance(mw, bw);
        const threshold = bw.length >= 9 ? 2 : 1;
        if (dist > 0 && dist <= threshold)
          return { type: "FUZZY", trigger: badWords[k], found: mw };
      }
    }
  }
  return null;
}
function checkFlood(username, text, userHistory) {
  if (!username || !text)
    return null;
  const now = Date.now();
  if (!userHistory[username])
    userHistory[username] = [];
  userHistory[username].push({ text, time: now });
  if (userHistory[username].length > 5)
    userHistory[username].shift();
  const h = userHistory[username];
  if (h.length >= 3) {
    const last3 = h.slice(-3);
    if (last3[0].text === text && last3[1].text === text && now - last3[0].time < 3e4)
      return "FLOOD (3x identique)";
  }
  return null;
}
function checkCaps(text) {
  if (!text || text.length < 10)
    return null;
  const letters = text.replace(/[^a-zA-Z]/g, "");
  if (letters.length < 6)
    return null;
  const caps = letters.replace(/[^A-Z]/g, "").length;
  const ratio = caps / letters.length;
  if (ratio > 0.8)
    return "CAPSLOCK (" + Math.round(ratio * 100) + "%)";
  return null;
}
function evaluateAIResult(result, toxicThreshold2 = 0.7, cleanThreshold2 = 0.4) {
  if (!result)
    return null;
  const score = typeof result === "object" ? result.score : result;
  if (score >= toxicThreshold2) {
    return { type: "AI_DETECTION", found: `toxic (${(score * 100).toFixed(0)}%)` };
  }
  if (score >= cleanThreshold2) {
    return { type: "AI_NEUTRAL", found: `neutral (${(score * 100).toFixed(0)}%)` };
  }
  return null;
}
class AhoCorasick {
  constructor(keywords) {
    this.trie = [{ next: {}, failure: 0, output: [] }];
    this.buildTrie(keywords);
    this.buildFailureLinks();
  }
  buildTrie(keywords) {
    for (const keyword of keywords) {
      let node = 0;
      for (const char of keyword) {
        if (!this.trie[node].next[char]) {
          this.trie[node].next[char] = this.trie.length;
          this.trie.push({ next: {}, failure: 0, output: [] });
        }
        node = this.trie[node].next[char];
      }
      this.trie[node].output.push(keyword);
    }
  }
  buildFailureLinks() {
    const queue = [];
    for (const char in this.trie[0].next) {
      const child = this.trie[0].next[char];
      queue.push(child);
    }
    while (queue.length > 0) {
      const u = queue.shift();
      for (const char in this.trie[u].next) {
        const v = this.trie[u].next[char];
        let f = this.trie[u].failure;
        while (f > 0 && !this.trie[f].next[char]) {
          f = this.trie[f].failure;
        }
        this.trie[v].failure = this.trie[f].next[char] || 0;
        this.trie[v].output = this.trie[v].output.concat(this.trie[this.trie[v].failure].output);
        queue.push(v);
      }
    }
  }
  search(text) {
    const results = [];
    let node = 0;
    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      while (node > 0 && !this.trie[node].next[char]) {
        node = this.trie[node].failure;
      }
      node = this.trie[node].next[char] || 0;
      if (this.trie[node].output.length > 0) {
        for (const word of this.trie[node].output) {
          results.push({ word, index: i - word.length + 1 });
        }
      }
    }
    return results;
  }
}
class BloomFilter {
  constructor(size = 1e3, hashCount = 3) {
    this.size = size;
    this.hashCount = hashCount;
    this.bitset = new Uint8Array(Math.ceil(size / 8));
  }
  _hash(item, seed) {
    let hash = seed;
    for (let i = 0; i < item.length; i++) {
      hash = (hash * 31 + item.charCodeAt(i)) % this.size;
    }
    return hash;
  }
  add(item) {
    for (let i = 0; i < this.hashCount; i++) {
      const h = this._hash(item, i);
      this.bitset[h >> 3] |= 1 << (h & 7);
    }
  }
  mightContain(item) {
    for (let i = 0; i < this.hashCount; i++) {
      const h = this._hash(item, i);
      if (!(this.bitset[h >> 3] & 1 << (h & 7))) {
        return false;
      }
    }
    return true;
  }
}
const DEFAULT_NEUTRAL_ACTION = "highlight";
const CONFIRM_KEYWORDS = ["Mute", "Exclure", "Confirm", "Yes", "Désactiver", "Désactive", "Désactivez"];
let ACTIVE_LEAGUES = ["color-league-grey"];
const LEAGUES = [
  { id: "color-league-grey", label: "Gry", color: "#aaaaaa" },
  { id: "color-league-bronze", short: "Brz", label: "Bronze", color: "#cd7f32" },
  { id: "color-league-silver", short: "Sil", label: "Argent", color: "#c9e7fe" },
  { id: "color-league-gold", short: "Gld", label: "Or", color: "#ffd700" },
  { id: "color-league-diamond", short: "Dia", label: "Diamant", color: "#d424ff" },
  { id: "color-league-royal", short: "Ryl", label: "Royal", color: "#e54500" }
];
const LEAGUE_TOLERANCE = {
  "color-league-grey": 0.75,
  "color-league-bronze": 0.82,
  "color-league-silver": 0.85,
  "color-league-gold": 0.9,
  "color-league-diamond": 0.95,
  "color-league-royal": 0.99,
  "default": 0.8
};
const DEFAULT_WHITELIST = ["petite", "strip", "mieux", "belle", "belles", "mille", "meilleur", "meilleure", "bonne", "donne", "sonne", "tonne", "canne", "panne", "vanne", "passe", "basse", "casse", "fasse", "lisse", "masse", "tasse", "lasse", "classe", "pure", "pate", "pote", "rate", "date", "gate", "hote", "note", "vote", "cote", "cure", "mure", "dure", "bure", "sure", "elle", "meme", "pere", "mere", "frere", "assis", "assez", "aussi", "ainsi", "pass", "bass", "mass", "grass", "glass", "class", "duck", "clock", "sock", "rock", "lock", "block", "dock", "beach", "peach", "teach", "reach", "sheet", "shirt", "shot", "shut", "hello", "help", "hell", "voiture", "rencontre", "vivre"];
const BAD_EMOJIS = ["🖕", "🤮", "🤢", "💩", "💀", "☠", "🩸", "💉", "🤡", "🤬"];
const DEFAULT_BAD_WORDS = BAD_EMOJIS.concat([
  "pute",
  "salope",
  "chienne",
  "conne",
  "grognasse",
  "pétasse",
  "truie",
  "moche",
  "thon",
  "grosse",
  "bite",
  "beurette",
  "viol",
  "violer",
  "avorte",
  "femelle",
  "nègre",
  "négro",
  "bougnoule",
  "pd",
  "pédale",
  "tapette",
  "enculé",
  "pedo",
  "pedophile",
  "enfant",
  "gamine",
  "mineur",
  "scato",
  "pisse",
  "caca",
  "zoo",
  "tuer",
  "meurtre",
  "baise",
  "connard",
  "fdp",
  "tg",
  "creve",
  "bitch",
  "slut",
  "whore",
  "cunt",
  "fuck",
  "asshole",
  "dick",
  "cock",
  "suck",
  "blowjob",
  "rape"
]);
const MUTE_BUTTON_SELECTOR = ".mute-button.mute-button-iconified";
let USER_HISTORY = {};
let MODEL_MUTED_USERS = {};
let LAST_URL = location.href;
let BAD_WORDS = [];
let WHITELIST = [];
let AHO_CORASICK = null;
let BLOOM_FILTER = null;
let isScanEnabled = false;
let isAutoMuteActive = false;
let cleanThreshold = 0.4;
let toxicThreshold = 0.7;
let neutralAction = DEFAULT_NEUTRAL_ACTION;
function buildAlgorithms() {
  try {
    const normalizedBadWords = BAD_WORDS.map((w) => normalizeText(w)).filter((w) => w.length > 0);
    AHO_CORASICK = new AhoCorasick(normalizedBadWords);
    BLOOM_FILTER = new BloomFilter(Math.max(1e3, normalizedBadWords.length * 10));
    normalizedBadWords.forEach((w) => BLOOM_FILTER.add(w));
  } catch (e) {
    console.error("Algorithm Error", e);
  }
}
function updateConfiguration(callback) {
  var _a2;
  if (!((_a2 = chrome.runtime) == null ? void 0 : _a2.id))
    return;
  try {
    chrome.storage.local.get({
      customBlacklist: [],
      customWhitelist: [],
      isEnabled: false,
      isAutoMuteActive: false,
      activeLeagues: ["color-league-grey"],
      cleanThreshold: 0.4,
      toxicThreshold: 0.7,
      neutralAction: DEFAULT_NEUTRAL_ACTION
    }, function(items) {
      if (chrome.runtime.lastError)
        return;
      BAD_WORDS = DEFAULT_BAD_WORDS.concat(items.customBlacklist);
      WHITELIST = DEFAULT_WHITELIST.concat(items.customWhitelist);
      isScanEnabled = items.isEnabled;
      isAutoMuteActive = items.isAutoMuteActive;
      ACTIVE_LEAGUES = items.activeLeagues;
      cleanThreshold = items.cleanThreshold;
      toxicThreshold = items.toxicThreshold;
      neutralAction = items.neutralAction;
      buildAlgorithms();
      if (callback)
        callback();
    });
  } catch (e) {
    console.warn("Storage error", e);
  }
}
function logToUI(msg, type, userInfo) {
  console.log("[AM-Knight] [Content] logToUI:", msg, type);
  try {
    chrome.runtime.sendMessage({ type: "LOG_TO_DEVTOOLS", msg, logType: type, userInfo });
  } catch (e) {
    console.error("[AM-Knight] [Content] logToUI error:", e);
  }
}
function extractMessageText(msgNode) {
  var _a2;
  if (!msgNode)
    return "";
  const clone = msgNode.cloneNode(true);
  (_a2 = clone.querySelector(".message-username")) == null ? void 0 : _a2.remove();
  clone.querySelectorAll("button").forEach((b) => b.remove());
  return clone.textContent.trim();
}
function getModelName() {
  const path = location.pathname.split("/");
  return path[1] || "unknown";
}
function handleMatch(msg, username, text, matchedLeague, match, isTargeted, aiInfo = "") {
  const reason = typeof match === "string" ? match : match.type + " (" + match.found + ")";
  const userInfo = { name: username, color: matchedLeague.color, fullMessage: text, found: match.found || null, aiInfo };
  const model = getModelName();
  if (!MODEL_MUTED_USERS[model])
    MODEL_MUTED_USERS[model] = /* @__PURE__ */ new Set();
  const mutedSet = MODEL_MUTED_USERS[model];
  const isAutoMuteSet = isAutoMuteActive && isTargeted;
  if (!isAutoMuteSet && match) {
    console.log(`[AM-Knight] 🔍 DIAGNOSTIC REFUS MUTE: GlobalMute=${isAutoMuteActive}, UserCiblé=${isTargeted}, LigueUser=${matchedLeague.id}, LiguesActives=${JSON.stringify(ACTIVE_LEAGUES)}`);
  }
  logToUI(`${isAutoMuteSet ? "MUTE" : "SCAN"} | ${reason} ${aiInfo}`, isAutoMuteSet ? "action" : "warn", userInfo);
  if (isAutoMuteSet && !mutedSet.has(username)) {
    const btn = msg.querySelector(MUTE_BUTTON_SELECTOR);
    if (btn && !btn.classList.contains("muted")) {
      mutedSet.add(username);
      const opts = { bubbles: true, cancelable: true, view: window };
      btn.dispatchEvent(new MouseEvent("mousedown", opts));
      const pressDuration = 50 + Math.floor(Math.random() * 100);
      setTimeout(() => {
        btn.dispatchEvent(new MouseEvent("mouseup", opts));
        btn.click();
        console.log(`[AM-Knight] 👆 MUTE (Humanized ${pressDuration}ms) sur: ${username}`);
        setTimeout(() => checkButtons(document.body), 100);
      }, pressDuration);
    } else if (!btn) {
      console.warn("[AM-Knight] Bouton MUTE non trouvé pour", username, "avec le sélecteur", MUTE_BUTTON_SELECTOR);
    }
  }
}
function handleNeutral(msg, username, text, matchedLeague, match, aiInfo = "") {
  const reason = match.found || "Neutral";
  const userInfo = { name: username, color: matchedLeague.color, fullMessage: text, found: match.found, aiInfo };
  logToUI(`NEUTRAL | ${reason} ${aiInfo}`, "warn", userInfo);
  if (neutralAction === "highlight") {
    msg.style.borderLeft = "4px solid #FFA500";
    msg.style.backgroundColor = "rgba(255, 165, 0, 0.1)";
  } else if (neutralAction === "hide") {
    msg.style.opacity = "0.3";
    msg.style.fontSize = "0.8em";
  }
}
function checkButtons(node) {
  if (!node || node.nodeType !== 1)
    return;
  const found = node.querySelectorAll('button, .button, [role="button"], .btn, .sc-button');
  for (let i = 0; i < found.length; i++) {
    const btn = found[i];
    const text = btn.textContent.trim();
    if (CONFIRM_KEYWORDS.some((k) => text.includes(k))) {
      const isAlreadyMuted = btn.classList.contains("muted") || btn.dataset.muted === "true";
      const isPureConfirm = text.includes("Désactiver") || text.includes("Confirm") || text.includes("Yes") || text.includes("Exclure");
      if (isPureConfirm || !isAlreadyMuted) {
        setTimeout(() => btn.click(), 50);
      }
    }
  }
}
function processMessages(node) {
  var _a2, _b;
  if (!((_a2 = chrome.runtime) == null ? void 0 : _a2.id) || !isScanEnabled)
    return;
  if (!node || node.nodeType !== 1)
    return;
  const messages = node.classList.contains("message-body") ? [node] : node.querySelectorAll(".message-body");
  for (let i = 0; i < messages.length; i++) {
    const msg = messages[i];
    if (msg.dataset.amScanned)
      continue;
    msg.dataset.amScanned = "true";
    const skipSelector = ".m-bg-public-tip, .m-bg-model, .lovense-toy-message, .lovense-tip-message, .goal-message, .user-muted-message, .group-show-user-joined-message, .invisible-mode-message, .m-line-menu-announce, .m-bg-fan-club-tip-discount, .m-bg-system";
    if (msg.matches(skipSelector) || msg.closest(skipSelector))
      continue;
    if (msg.querySelector(".username-role-icon.knight"))
      continue;
    let matchedLeague = null;
    let isTargeted = false;
    let finalTolerance = LEAGUE_TOLERANCE["default"];
    const exSup = Array.from(msg.querySelectorAll("sup")).find((el) => el.textContent.trim().toLowerCase() === "ex");
    if (exSup) {
      const parent = exSup.parentElement;
      for (const league of LEAGUES) {
        if (parent && parent.classList.contains(league.id)) {
          matchedLeague = league;
          finalTolerance = LEAGUE_TOLERANCE[league.id];
          if (ACTIVE_LEAGUES.includes(league.id))
            isTargeted = true;
          break;
        }
      }
    }
    if (!matchedLeague) {
      for (const league of LEAGUES) {
        const leagueEl = msg.querySelector("." + league.id);
        if (leagueEl) {
          matchedLeague = league;
          finalTolerance = LEAGUE_TOLERANCE[league.id];
          if (leagueEl.querySelector(".username-role-icon.king"))
            finalTolerance = 0.99;
          if (ACTIVE_LEAGUES.includes(league.id))
            isTargeted = true;
          break;
        }
      }
    }
    if (!matchedLeague)
      matchedLeague = { label: "Guest", color: "#888" };
    const username = (((_b = msg.querySelector(".message-username")) == null ? void 0 : _b.textContent) || "Unknown").trim();
    const text = extractMessageText(msg);
    const match = fuzzyCheck(text, AHO_CORASICK, BLOOM_FILTER, BAD_WORDS, WHITELIST) || checkFlood(username, text, USER_HISTORY) || checkCaps(text);
    chrome.runtime.sendMessage({ type: "AI_REQUEST", text }, (result) => {
      if (chrome.runtime.lastError)
        return;
      const score = result ? typeof result === "object" ? result.score : result : 0;
      const diag = result && typeof result === "object" && result.diag ? ` | ${result.diag}` : "";
      const scorePct = (score * 100).toFixed(1);
      const limitPct = (finalTolerance * 100).toFixed(0);
      const aiInfo = `| Score: ${scorePct}% | Limit: ${limitPct}% (${matchedLeague.label})${diag}`;
      if (match) {
        handleMatch(msg, username, text, matchedLeague, match, isTargeted, aiInfo);
      } else {
        const aiMatch = evaluateAIResult(result, toxicThreshold, cleanThreshold);
        if (aiMatch && aiMatch.type === "AI_NEUTRAL") {
          handleNeutral(msg, username, text, matchedLeague, aiMatch, aiInfo);
        } else if (aiMatch) {
          handleMatch(msg, username, text, matchedLeague, aiMatch, isTargeted, aiInfo);
        } else {
          const status = text.split(/\s+/).length < 3 ? "SHORT" : "OK";
          logToUI(`SCAN | ${status} ${aiInfo}`, "safe", { name: username, color: matchedLeague.color, fullMessage: text, aiInfo });
        }
      }
    });
  }
}
function throttle(func, limit) {
  let inThrottle;
  return function() {
    if (!inThrottle) {
      func.apply(this, arguments);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
}
const throttledProcess = throttle((node) => {
  processMessages(node);
  checkButtons(node);
}, 200);
const globalObserver = new MutationObserver((mutations) => {
  mutations.forEach((m) => {
    m.addedNodes.forEach((node) => {
      if (node.nodeType === 1)
        throttledProcess(node);
    });
  });
});
function start() {
  if (!document.body)
    return;
  try {
    globalObserver.disconnect();
  } catch (e) {
  }
  globalObserver.observe(document.body, { childList: true, subtree: true });
  processMessages(document.body);
  checkButtons(document.body);
}
updateConfiguration(() => start());
if ((_a = chrome.runtime) == null ? void 0 : _a.id) {
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === "local") {
      if (changes.isEnabled)
        isScanEnabled = changes.isEnabled.newValue;
      if (changes.isAutoMuteActive)
        isAutoMuteActive = changes.isAutoMuteActive.newValue;
      if (changes.activeLeagues)
        ACTIVE_LEAGUES = changes.activeLeagues.newValue;
      if (changes.cleanThreshold)
        cleanThreshold = changes.cleanThreshold.newValue;
      if (changes.toxicThreshold)
        toxicThreshold = changes.toxicThreshold.newValue;
      if (changes.neutralAction)
        neutralAction = changes.neutralAction.newValue;
      if (changes.customBlacklist || changes.customWhitelist) {
        updateConfiguration();
      }
      console.log("[AM-Knight] Réglages mis à jour en direct.");
    }
  });
}
setInterval(() => {
  if (location.pathname !== LAST_URL) {
    LAST_URL = location.pathname;
    USER_HISTORY = {};
    updateConfiguration(start);
  }
}, 3e3);
//# sourceMappingURL=index.js-464258c0.js.map
})()
