import "./modulepreload-polyfill-7faf532e.js";
import { r as ref, o as onMounted, b as openBlock, c as createElementBlock, d as createBaseVNode, w as withDirectives, l as vModelCheckbox, h as normalizeStyle, t as toDisplayString, n as normalizeClass, i as createApp } from "./vue-dfb4c6b9.js";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.js";
const Popup_vue_vue_type_style_index_0_scoped_369b01b4_lang = "";
const _hoisted_1 = { class: "popup-container" };
const _hoisted_2 = { class: "status-indicator" };
const _hoisted_3 = { class: "control-row" };
const _hoisted_4 = { class: "switch" };
const _hoisted_5 = { class: "switch" };
const _hoisted_6 = ["disabled"];
const _hoisted_7 = { class: "control-row" };
const _hoisted_8 = { class: "switch" };
const _sfc_main = {
  __name: "Popup",
  setup(__props) {
    const isEnabled = ref(false);
    const isAutoMuteActive = ref(false);
    const isUiVisible = ref(false);
    onMounted(() => {
      chrome.storage.local.get(["isEnabled", "isAutoMuteActive", "isUiVisible"], (items) => {
        isEnabled.value = items.isEnabled || false;
        isAutoMuteActive.value = items.isAutoMuteActive || false;
        isUiVisible.value = items.isUiVisible || false;
      });
    });
    const saveSettings = () => {
      chrome.storage.local.set({
        isEnabled: isEnabled.value,
        isAutoMuteActive: isAutoMuteActive.value,
        isUiVisible: isUiVisible.value
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        _cache[9] || (_cache[9] = createBaseVNode("h3", null, "Auto-Mute Knight", -1)),
        createBaseVNode("div", _hoisted_2, [
          createBaseVNode("div", _hoisted_3, [
            _cache[4] || (_cache[4] = createBaseVNode("span", null, "Scan Active", -1)),
            createBaseVNode("label", _hoisted_4, [
              withDirectives(createBaseVNode("input", {
                type: "checkbox",
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isEnabled.value = $event),
                onChange: saveSettings
              }, null, 544), [
                [vModelCheckbox, isEnabled.value]
              ]),
              _cache[3] || (_cache[3] = createBaseVNode("span", { class: "slider" }, null, -1))
            ])
          ]),
          createBaseVNode("div", {
            class: "control-row",
            style: normalizeStyle({ opacity: isEnabled.value ? 1 : 0.3 })
          }, [
            _cache[6] || (_cache[6] = createBaseVNode("span", null, "Auto-Mute", -1)),
            createBaseVNode("label", _hoisted_5, [
              withDirectives(createBaseVNode("input", {
                type: "checkbox",
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isAutoMuteActive.value = $event),
                onChange: saveSettings,
                disabled: !isEnabled.value
              }, null, 40, _hoisted_6), [
                [vModelCheckbox, isAutoMuteActive.value]
              ]),
              _cache[5] || (_cache[5] = createBaseVNode("span", { class: "slider" }, null, -1))
            ])
          ], 4),
          createBaseVNode("div", _hoisted_7, [
            _cache[8] || (_cache[8] = createBaseVNode("span", null, "Console", -1)),
            createBaseVNode("label", _hoisted_8, [
              withDirectives(createBaseVNode("input", {
                type: "checkbox",
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isUiVisible.value = $event),
                onChange: saveSettings
              }, null, 544), [
                [vModelCheckbox, isUiVisible.value]
              ]),
              _cache[7] || (_cache[7] = createBaseVNode("span", { class: "slider" }, null, -1))
            ])
          ])
        ]),
        createBaseVNode("div", {
          class: normalizeClass(["status", { enabled: isEnabled.value }])
        }, toDisplayString(isEnabled.value ? "ENABLED" : "DISABLED"), 3)
      ]);
    };
  }
};
const Popup = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-369b01b4"]]);
createApp(Popup).mount("#app");
//# sourceMappingURL=popup.html-2949ed0a.js.map
