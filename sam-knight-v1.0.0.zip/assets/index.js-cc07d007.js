const OFFSCREEN_DOCUMENT_PATH = "offscreen.html";
let creatingOffscreenPromise = null;
const devtoolsPorts = {};
async function setupOffscreen() {
  if (await chrome.offscreen.hasDocument()) {
    return;
  }
  if (creatingOffscreenPromise) {
    await creatingOffscreenPromise;
    return;
  }
  creatingOffscreenPromise = chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_PATH,
    reasons: [chrome.offscreen.Reason.WORKERS],
    justification: "AI processing for message filtering"
  });
  await creatingOffscreenPromise;
  creatingOffscreenPromise = null;
}
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "devtools-panel")
    return;
  let tabId;
  const extensionListener = (message) => {
    if (message.type === "init") {
      tabId = message.tabId;
      devtoolsPorts[tabId] = port;
      console.log(`[AM-Knight] [Background] DevTools connecté pour l'onglet ${tabId}`);
    }
  };
  port.onMessage.addListener(extensionListener);
  port.onDisconnect.addListener(() => {
    port.onMessage.removeListener(extensionListener);
    if (tabId)
      delete devtoolsPorts[tabId];
    console.log(`[AM-Knight] [Background] DevTools déconnecté pour l'onglet ${tabId}`);
  });
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "LOG_TO_DEVTOOLS") {
    const tabId = sender.tab ? sender.tab.id : null;
    if (tabId && devtoolsPorts[tabId]) {
      devtoolsPorts[tabId].postMessage({
        type: "LOG",
        msg: message.msg,
        logType: message.logType,
        userInfo: message.userInfo
      });
    } else {
      console.warn(`[AM-Knight] [Background] No DevTools port for tab ${tabId}. Open ports:`, Object.keys(devtoolsPorts));
    }
    return false;
  }
  if (message.type === "AI_REQUEST") {
    setupOffscreen().then(() => {
      chrome.runtime.sendMessage({
        type: "AI_CHECK",
        text: message.text
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn("[AM-Knight] [Background] Erreur communication offscreen:", chrome.runtime.lastError);
          sendResponse(null);
        } else {
          if (response) {
            const score = typeof response === "object" ? response.score : response;
            const diag = response.diag ? ` | ${response.diag}` : "";
            console.log(`[AM-Knight] [AI] "${message.text.substring(0, 30)}..." -> ${(score * 100).toFixed(1)}%${diag}`);
          }
          sendResponse(response);
        }
      });
    }).catch((err) => {
      console.error("[AM-Knight] [Background] Échec setupOffscreen:", err);
      sendResponse(null);
    });
    return true;
  }
});
chrome.runtime.onInstalled.addListener(() => {
  setupOffscreen();
});
//# sourceMappingURL=index.js-cc07d007.js.map
