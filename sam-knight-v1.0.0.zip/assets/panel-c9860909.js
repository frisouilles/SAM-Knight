import "./modulepreload-polyfill-7faf532e.js";
import { r as ref, a as reactive, o as onMounted, b as openBlock, c as createElementBlock, d as createBaseVNode, n as normalizeClass, t as toDisplayString, F as Fragment, e as renderList, f as createCommentVNode, g as nextTick, h as normalizeStyle, i as createApp } from "./vue-dfb4c6b9.js";
const _imports_0 = "/icon.png";
const Panel_vue_vue_type_style_index_0_lang = "";
const _hoisted_1 = { class: "devtools-panel" };
const _hoisted_2 = { class: "panel-header" };
const _hoisted_3 = { class: "header-controls" };
const _hoisted_4 = { class: "header-right" };
const _hoisted_5 = { class: "count" };
const _hoisted_6 = { class: "leagues-bar" };
const _hoisted_7 = ["onClick", "title"];
const _hoisted_8 = { class: "log-row info-row" };
const _hoisted_9 = { class: "col-time" };
const _hoisted_10 = { class: "col-meta" };
const _hoisted_11 = {
  key: 1,
  class: "username system"
};
const _hoisted_12 = {
  key: 2,
  class: "ai-details"
};
const _hoisted_13 = {
  key: 3,
  class: "ai-details"
};
const _hoisted_14 = { class: "col-actions" };
const _hoisted_15 = {
  key: 0,
  class: "quick-actions"
};
const _hoisted_16 = ["onClick"];
const _hoisted_17 = ["onClick"];
const _hoisted_18 = ["onClick"];
const _hoisted_19 = { class: "log-row message-row" };
const _hoisted_20 = { class: "col-message" };
const _hoisted_21 = {
  key: 0,
  class: "message-content"
};
const _hoisted_22 = ["innerHTML"];
const _hoisted_23 = {
  key: 0,
  class: "empty-state"
};
const _hoisted_24 = { class: "empty-content" };
const _hoisted_25 = {
  key: 0,
  style: { "color": "#ffaa00" }
};
const _sfc_main = {
  __name: "Panel",
  setup(__props) {
    const logs = ref([]);
    const logContainer = ref(null);
    const autoScroll = ref(true);
    const leagues = [
      { id: "color-league-grey", short: "Gry", label: "Gris", color: "#aaaaaa" },
      { id: "color-league-bronze", short: "Brz", label: "Bronze", color: "#cd7f32" },
      { id: "color-league-silver", short: "Sil", label: "Argent", color: "#c9e7fe" },
      { id: "color-league-gold", short: "Gld", label: "Or", color: "#ffd700" },
      { id: "color-league-diamond", short: "Dia", label: "Diamant", color: "#d424ff" },
      { id: "color-league-royal", short: "Ryl", label: "Royal", color: "#e54500" }
    ];
    const settings = reactive({
      isEnabled: false,
      isAutoMuteActive: false,
      activeLeagues: ["color-league-grey"]
    });
    const loadSettings = () => {
      var _a;
      if (!((_a = chrome.runtime) == null ? void 0 : _a.id))
        return;
      chrome.storage.local.get({
        isEnabled: false,
        isAutoMuteActive: false,
        activeLeagues: ["color-league-grey"]
      }, (items) => {
        settings.isEnabled = items.isEnabled;
        settings.isAutoMuteActive = items.isAutoMuteActive;
        settings.activeLeagues = items.activeLeagues;
      });
    };
    const toggleSetting = (key) => {
      var _a;
      if (!((_a = chrome.runtime) == null ? void 0 : _a.id))
        return;
      settings[key] = !settings[key];
      saveSettings();
    };
    const toggleLeague = (leagueId) => {
      var _a;
      if (!((_a = chrome.runtime) == null ? void 0 : _a.id))
        return;
      const index = settings.activeLeagues.indexOf(leagueId);
      if (index === -1) {
        settings.activeLeagues.push(leagueId);
      } else {
        settings.activeLeagues.splice(index, 1);
      }
      saveSettings();
    };
    const saveSettings = () => {
      var _a;
      if (!((_a = chrome.runtime) == null ? void 0 : _a.id))
        return;
      try {
        chrome.storage.local.set({
          isEnabled: settings.isEnabled,
          isAutoMuteActive: settings.isAutoMuteActive,
          activeLeagues: [...settings.activeLeagues]
        });
      } catch (e) {
        console.warn("Storage error", e);
      }
    };
    const clearLogs = () => {
      logs.value = [];
    };
    const highlightMessage = (userInfo) => {
      let text = userInfo.fullMessage;
      if (userInfo.found) {
        const escaped = userInfo.found.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        try {
          const regex = new RegExp("(" + escaped + ")", "gi");
          text = text.replace(regex, "<b style='color:#ff5555; text-decoration:underline; background:rgba(255,0,0,0.1);'>$1</b>");
        } catch (e) {
          console.error("Regex error", e);
        }
      }
      return text;
    };
    const saveExample = (log, label) => {
      var _a;
      log.feedback = label;
      const text = log.userInfo.fullMessage;
      if (!((_a = chrome.runtime) == null ? void 0 : _a.id))
        return;
      chrome.storage.local.get({ trainingDataset: [] }, (items) => {
        const data = items.trainingDataset;
        if (!data.some((d) => d.text === text)) {
          data.push({ text, label, date: Date.now() });
          chrome.storage.local.set({ trainingDataset: data });
        }
      });
    };
    const scrollToBottom = () => {
      if (autoScroll.value && logContainer.value) {
        logContainer.value.scrollTop = logContainer.value.scrollHeight;
      }
    };
    onMounted(() => {
      loadSettings();
      chrome.storage.onChanged.addListener((changes, ns) => {
        if (ns === "local") {
          if (changes.isEnabled)
            settings.isEnabled = changes.isEnabled.newValue;
          if (changes.isAutoMuteActive)
            settings.isAutoMuteActive = changes.isAutoMuteActive.newValue;
          if (changes.activeLeagues)
            settings.activeLeagues = changes.activeLeagues.newValue;
        }
      });
      let port = null;
      const connectToBackground = () => {
        try {
          port = chrome.runtime.connect({ name: "devtools-panel" });
          port.postMessage({ type: "init", tabId: chrome.devtools.inspectedWindow.tabId });
          port.onMessage.addListener((message) => {
            if (message.type === "LOG") {
              logs.value.push({
                time: (/* @__PURE__ */ new Date()).toLocaleTimeString(),
                type: message.logType,
                msg: message.msg,
                userInfo: message.userInfo,
                feedback: null
              });
              if (logs.value.length > 500)
                logs.value.shift();
              nextTick(scrollToBottom);
            }
          });
          port.onDisconnect.addListener(() => {
            console.warn("[AM-Knight] DevTools port disconnected. Reconnecting...");
            port = null;
            setTimeout(connectToBackground, 1e3);
          });
          console.log("[AM-Knight] DevTools port connected.");
        } catch (e) {
          console.error("[AM-Knight] Connection failed", e);
          setTimeout(connectToBackground, 2e3);
        }
      };
      connectToBackground();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("header", _hoisted_2, [
          _cache[2] || (_cache[2] = createBaseVNode("div", { class: "header-left" }, [
            createBaseVNode("img", {
              src: _imports_0,
              class: "logo"
            }),
            createBaseVNode("span", { class: "title" }, "AM-KNIGHT")
          ], -1)),
          createBaseVNode("div", _hoisted_3, [
            createBaseVNode("button", {
              class: normalizeClass(["btn-toggle", { active: settings.isEnabled }]),
              onClick: _cache[0] || (_cache[0] = ($event) => toggleSetting("isEnabled")),
              title: "Activer/Désactiver le scan global"
            }, " SCAN: " + toDisplayString(settings.isEnabled ? "ON" : "OFF"), 3),
            createBaseVNode("button", {
              class: normalizeClass(["btn-toggle", { active: settings.isAutoMuteActive, danger: settings.isAutoMuteActive }]),
              onClick: _cache[1] || (_cache[1] = ($event) => toggleSetting("isAutoMuteActive")),
              title: "Activer/Désactiver le MUTE automatique"
            }, " MUTE: " + toDisplayString(settings.isAutoMuteActive ? "ON" : "OFF"), 3)
          ]),
          createBaseVNode("div", _hoisted_4, [
            createBaseVNode("button", {
              onClick: clearLogs,
              class: "btn-clear",
              title: "Effacer la console"
            }, "CLR"),
            createBaseVNode("span", _hoisted_5, toDisplayString(logs.value.length), 1)
          ])
        ]),
        createBaseVNode("div", _hoisted_6, [
          _cache[3] || (_cache[3] = createBaseVNode("span", { class: "label" }, "Ligues:", -1)),
          (openBlock(), createElementBlock(Fragment, null, renderList(leagues, (league) => {
            return createBaseVNode("button", {
              key: league.id,
              class: normalizeClass(["league-chip", { active: settings.activeLeagues.includes(league.id) }]),
              style: normalizeStyle({ borderColor: league.color, color: settings.activeLeagues.includes(league.id) ? "#fff" : league.color, backgroundColor: settings.activeLeagues.includes(league.id) ? league.color : "transparent" }),
              onClick: ($event) => toggleLeague(league.id),
              title: "Cibler les " + league.label
            }, toDisplayString(league.short), 15, _hoisted_7);
          }), 64))
        ]),
        createBaseVNode("div", {
          class: "log-container",
          ref_key: "logContainer",
          ref: logContainer
        }, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(logs.value, (log, index) => {
            return openBlock(), createElementBlock("div", {
              key: index,
              class: normalizeClass(["log-entry", log.type])
            }, [
              createBaseVNode("div", _hoisted_8, [
                createBaseVNode("div", _hoisted_9, toDisplayString(log.time), 1),
                createBaseVNode("div", _hoisted_10, [
                  log.userInfo ? (openBlock(), createElementBlock("span", {
                    key: 0,
                    class: "username",
                    style: normalizeStyle({ color: log.userInfo.color })
                  }, toDisplayString(log.userInfo.name), 5)) : (openBlock(), createElementBlock("span", _hoisted_11, "System")),
                  log.userInfo && log.userInfo.aiInfo ? (openBlock(), createElementBlock("span", _hoisted_12, toDisplayString(log.userInfo.aiInfo), 1)) : (openBlock(), createElementBlock("span", _hoisted_13, toDisplayString(log.msg), 1))
                ]),
                createBaseVNode("div", _hoisted_14, [
                  !log.feedback && log.userInfo && log.userInfo.fullMessage ? (openBlock(), createElementBlock("div", _hoisted_15, [
                    createBaseVNode("span", {
                      onClick: ($event) => saveExample(log, "clean"),
                      title: "Marquer comme Propre",
                      class: "action-btn"
                    }, "✅", 8, _hoisted_16),
                    createBaseVNode("span", {
                      onClick: ($event) => saveExample(log, "neutral"),
                      title: "Marquer comme Neutre",
                      class: "action-btn"
                    }, "🟧", 8, _hoisted_17),
                    createBaseVNode("span", {
                      onClick: ($event) => saveExample(log, "toxic"),
                      title: "Marquer comme Toxique",
                      class: "action-btn"
                    }, "❌", 8, _hoisted_18)
                  ])) : log.feedback ? (openBlock(), createElementBlock("div", {
                    key: 1,
                    class: normalizeClass(["feedback-badge", log.feedback])
                  }, toDisplayString(log.feedback === "clean" ? "CLEAN" : log.feedback === "neutral" ? "NEUTRE" : "TOXIQUE"), 3)) : createCommentVNode("", true)
                ])
              ]),
              createBaseVNode("div", _hoisted_19, [
                _cache[4] || (_cache[4] = createBaseVNode("div", { class: "col-indent" }, null, -1)),
                createBaseVNode("div", _hoisted_20, [
                  !log.userInfo || !log.userInfo.fullMessage ? (openBlock(), createElementBlock("span", _hoisted_21, toDisplayString(log.msg), 1)) : (openBlock(), createElementBlock("span", {
                    key: 1,
                    class: "message-content full-text",
                    innerHTML: highlightMessage(log.userInfo)
                  }, null, 8, _hoisted_22))
                ])
              ])
            ], 2);
          }), 128)),
          logs.value.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_23, [
            createBaseVNode("div", _hoisted_24, [
              _cache[5] || (_cache[5] = createBaseVNode("p", null, "En attente de messages...", -1)),
              !settings.isEnabled ? (openBlock(), createElementBlock("p", _hoisted_25, "⚠️ LE SCAN EST DÉSACTIVÉ")) : createCommentVNode("", true)
            ])
          ])) : createCommentVNode("", true)
        ], 512)
      ]);
    };
  }
};
createApp(_sfc_main).mount("#app");
//# sourceMappingURL=panel-c9860909.js.map
