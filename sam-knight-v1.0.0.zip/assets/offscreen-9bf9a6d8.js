import "./modulepreload-polyfill-7faf532e.js";
class AIBridge {
  constructor(worker) {
    this.worker = worker;
    this.ready = false;
    this.callbacks = /* @__PURE__ */ new Map();
    this.requestId = 0;
    if (this.worker) {
      this.worker.onmessage = (e) => {
        if (e.data.type === "READY") {
          this.ready = true;
          console.info("[AM-Knight] [AI-Bridge] IA prête et chargée.");
        }
        if (e.data.type === "RESULT") {
          const cb = this.callbacks.get(e.data.id);
          if (cb) {
            cb({
              score: e.data.score,
              label: e.data.label,
              diag: e.data.diag
              // Relais du diagnostic
            });
            this.callbacks.delete(e.data.id);
          }
        }
      };
    }
  }
  async init(vocab = {}) {
    if (this.worker) {
      console.log("[AM-Knight] [AI-Bridge] Initialisation du Worker...");
      this.worker.postMessage({ type: "INIT", config: { vocab } });
    }
  }
  check(text) {
    return new Promise((resolve) => {
      if (!this.ready || !this.worker) {
        if (!this.ready)
          console.warn("[AM-Knight] [AI-Bridge] IA pas encore prête, scan ignoré.");
        return resolve(0);
      }
      this.requestId++;
      const id = this.requestId;
      this.callbacks.set(id, resolve);
      this.worker.postMessage({ type: "PREDICT", text, id });
    });
  }
}
const workerUrl = chrome.runtime.getURL("assets/ai-worker.js");
const aiWorker = new Worker(workerUrl, { type: "module" });
const bridge = new AIBridge(aiWorker);
console.log("[AM-Knight] [Offscreen] Document chargé, Worker IA initialisé.");
bridge.init();
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "AI_CHECK") {
    bridge.check(message.text).then((result) => {
      sendResponse(result);
    }).catch((err) => {
      console.error("[AM-Knight] [Offscreen] Erreur AI check:", err);
      sendResponse(null);
    });
    return true;
  }
});
//# sourceMappingURL=offscreen-9bf9a6d8.js.map
