import "./modulepreload-polyfill-7faf532e.js";
import { r as ref, j as computed, o as onMounted, b as openBlock, c as createElementBlock, d as createBaseVNode, w as withDirectives, v as vModelText, t as toDisplayString, n as normalizeClass, f as createCommentVNode, h as normalizeStyle, k as vModelSelect, i as createApp } from "./vue-dfb4c6b9.js";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.js";
const Options_vue_vue_type_style_index_0_scoped_7d2496b8_lang = "";
const _hoisted_1 = { class: "options-container" };
const _hoisted_2 = { class: "section" };
const _hoisted_3 = { class: "section" };
const _hoisted_4 = ["disabled"];
const _hoisted_5 = { class: "section" };
const _hoisted_6 = { class: "threshold-visualizer" };
const _hoisted_7 = { class: "control-group" };
const _hoisted_8 = ["max"];
const _hoisted_9 = { class: "control-group" };
const _hoisted_10 = ["min"];
const _hoisted_11 = { class: "control-group" };
const _hoisted_12 = { class: "section" };
const _hoisted_13 = { class: "stats-box" };
const _hoisted_14 = { class: "stat-item" };
const _hoisted_15 = { class: "stat-value" };
const _hoisted_16 = {
  class: "stat-item",
  style: { "color": "#4cd964" }
};
const _hoisted_17 = { class: "stat-value" };
const _hoisted_18 = {
  class: "stat-item",
  style: { "color": "#ff3b30" }
};
const _hoisted_19 = { class: "stat-value" };
const _hoisted_20 = { class: "actions-row" };
const _hoisted_21 = ["disabled"];
const _hoisted_22 = ["disabled"];
const _hoisted_23 = {
  key: 0,
  class: "mini-preview"
};
const _sfc_main = {
  __name: "Options",
  setup(__props) {
    const blacklistText = ref("");
    const whitelistText = ref("");
    const saving = ref(false);
    const statusMsg = ref("");
    const statusType = ref("success");
    const cleanThreshold = ref(0.4);
    const toxicThreshold = ref(0.7);
    const neutralAction = ref("highlight");
    const trainingData = ref([]);
    const importInput = ref(null);
    const triggerImport = () => {
      importInput.value.click();
    };
    const handleImport = (e) => {
      const file = e.target.files[0];
      if (!file)
        return;
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target.result;
        const lines = text.split(/\r\n|\n/);
        let importedCount = 0;
        chrome.storage.local.get({ trainingDataset: [] }, (items) => {
          const currentData = items.trainingDataset;
          const currentTexts = new Set(currentData.map((d) => d.text));
          lines.forEach((line) => {
            const matches = line.match(/^(?:\"([^\"]*(?:\"\"[^\"]*)*)\"|([^,]*)),(.*)$/);
            if (matches) {
              let msgText = matches[1] || matches[2];
              const label = matches[3].trim();
              if (msgText && label && (label === "clean" || label.includes("toxic"))) {
                msgText = msgText.replace(/\"\"/g, '"').trim();
                if (!currentTexts.has(msgText) && msgText !== "text") {
                  currentData.push({ text: msgText, label, date: Date.now() });
                  currentTexts.add(msgText);
                  importedCount++;
                }
              }
            }
          });
          chrome.storage.local.set({ trainingDataset: currentData }, () => {
            refreshStats();
            statusMsg.value = `Import terminé : ${importedCount} nouveaux messages ajoutés.`;
            statusType.value = "success";
            setTimeout(() => {
              statusMsg.value = "";
            }, 5e3);
          });
        });
      };
      reader.readAsText(file);
      e.target.value = "";
    };
    const datasetStats = computed(() => {
      const clean = trainingData.value.filter((d) => d.label === "clean").length;
      const toxic = trainingData.value.filter((d) => d.label === "toxic").length;
      return {
        total: trainingData.value.length,
        clean,
        toxic
      };
    });
    const lastAdded = computed(() => {
      if (trainingData.value.length === 0)
        return "Aucun";
      const last = trainingData.value[trainingData.value.length - 1];
      return `[${last.label}] ${last.text.substring(0, 50)}...`;
    });
    const refreshStats = () => {
      chrome.storage.local.get({ trainingDataset: [] }, (items) => {
        trainingData.value = items.trainingDataset;
      });
    };
    const downloadCsv = () => {
      if (trainingData.value.length === 0)
        return;
      let csvContent = "data:text/csv;charset=utf-8,text,label\n";
      trainingData.value.forEach(function(row) {
        const safeText = row.text.replace(/"/g, '""').replace(/\n/g, " ");
        csvContent += `"${safeText}",${row.label}
`;
      });
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", `stripchat_dataset_${trainingData.value.length}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };
    const clearDataset = () => {
      if (!confirm("Voulez-vous vraiment effacer TOUTES les données d'entraînement ?"))
        return;
      chrome.storage.local.set({ trainingDataset: [] }, () => {
        refreshStats();
        statusMsg.value = "Dataset effacé.";
        statusType.value = "success";
        setTimeout(() => {
          statusMsg.value = "";
        }, 3e3);
      });
    };
    onMounted(() => {
      chrome.storage.local.get({
        customBlacklist: [],
        customWhitelist: [],
        trainingDataset: [],
        isAutoMuteActive: false,
        cleanThreshold: 0.4,
        toxicThreshold: 0.7,
        neutralAction: "highlight"
      }, (items) => {
        blacklistText.value = items.customBlacklist.join("\n");
        whitelistText.value = items.customWhitelist.join("\n");
        trainingData.value = items.trainingDataset;
        cleanThreshold.value = items.cleanThreshold;
        toxicThreshold.value = items.toxicThreshold;
        neutralAction.value = items.neutralAction;
      });
    });
    const saveOptions = () => {
      saving.value = true;
      const blacklistArray = blacklistText.value.split(/[\n,]+/).map((s) => s.trim()).filter((s) => s.length > 0);
      const whitelistArray = whitelistText.value.split(/[\n,]+/).map((s) => s.trim()).filter((s) => s.length > 0);
      chrome.storage.local.set({
        customBlacklist: blacklistArray,
        customWhitelist: whitelistArray,
        cleanThreshold: cleanThreshold.value,
        toxicThreshold: toxicThreshold.value,
        neutralAction: neutralAction.value
      }, () => {
        saving.value = false;
        statusMsg.value = "Options enregistrées !";
        statusType.value = "success";
        setTimeout(() => {
          statusMsg.value = "";
        }, 3e3);
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        _cache[20] || (_cache[20] = createBaseVNode("h1", null, "Configuration Auto-Mute Knight", -1)),
        createBaseVNode("div", _hoisted_2, [
          _cache[5] || (_cache[5] = createBaseVNode("h2", null, "Blacklist Personnalisée", -1)),
          _cache[6] || (_cache[6] = createBaseVNode("p", { class: "help" }, "Ajoutez ici des mots ou expressions à bannir (un par ligne ou séparés par des virgules).", -1)),
          withDirectives(createBaseVNode("textarea", {
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => blacklistText.value = $event),
            placeholder: "exemple, mot interdit, spam"
          }, null, 512), [
            [vModelText, blacklistText.value]
          ])
        ]),
        createBaseVNode("div", _hoisted_3, [
          _cache[7] || (_cache[7] = createBaseVNode("h2", null, "Whitelist Personnalisée", -1)),
          _cache[8] || (_cache[8] = createBaseVNode("p", { class: "help" }, "Ajoutez ici des mots autorisés (un par ligne ou séparés par des virgules).", -1)),
          withDirectives(createBaseVNode("textarea", {
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => whitelistText.value = $event),
            placeholder: "bonjour, ça va, ..."
          }, null, 512), [
            [vModelText, whitelistText.value]
          ])
        ]),
        createBaseVNode("button", {
          onClick: saveOptions,
          disabled: saving.value
        }, toDisplayString(saving.value ? "Enregistrement..." : "Enregistrer les modifications"), 9, _hoisted_4),
        statusMsg.value ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(["status", statusType.value])
        }, toDisplayString(statusMsg.value), 3)) : createCommentVNode("", true),
        _cache[21] || (_cache[21] = createBaseVNode("hr", { style: { "border": "0", "border-top": "1px solid #444", "margin": "30px 0" } }, null, -1)),
        createBaseVNode("div", _hoisted_5, [
          _cache[13] || (_cache[13] = createBaseVNode("h2", null, "🎛️ Réglages de Sensibilité", -1)),
          _cache[14] || (_cache[14] = createBaseVNode("p", { class: "help" }, "Définissez les zones de tolérance pour l'IA.", -1)),
          createBaseVNode("div", _hoisted_6, [
            createBaseVNode("div", {
              class: "zone clean",
              style: normalizeStyle({ width: cleanThreshold.value * 100 + "%" })
            }, "Clean", 4),
            createBaseVNode("div", {
              class: "zone neutral",
              style: normalizeStyle({ width: (toxicThreshold.value - cleanThreshold.value) * 100 + "%" })
            }, "Neutre", 4),
            createBaseVNode("div", {
              class: "zone toxic",
              style: normalizeStyle({ width: (1 - toxicThreshold.value) * 100 + "%" })
            }, "Toxique", 4)
          ]),
          createBaseVNode("div", _hoisted_7, [
            createBaseVNode("label", null, "Limite Clean / Neutre (" + toDisplayString((cleanThreshold.value * 100).toFixed(0)) + "%)", 1),
            withDirectives(createBaseVNode("input", {
              type: "range",
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => cleanThreshold.value = $event),
              min: "0.1",
              max: toxicThreshold.value - 0.05,
              step: "0.05"
            }, null, 8, _hoisted_8), [
              [
                vModelText,
                cleanThreshold.value,
                void 0,
                { number: true }
              ]
            ]),
            _cache[9] || (_cache[9] = createBaseVNode("p", { class: "help-text" }, "En dessous de ce score, le message est considéré comme sûr.", -1))
          ]),
          createBaseVNode("div", _hoisted_9, [
            createBaseVNode("label", null, "Limite Neutre / Toxique (" + toDisplayString((toxicThreshold.value * 100).toFixed(0)) + "%)", 1),
            withDirectives(createBaseVNode("input", {
              type: "range",
              "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => toxicThreshold.value = $event),
              min: cleanThreshold.value + 0.05,
              max: "0.95",
              step: "0.05"
            }, null, 8, _hoisted_10), [
              [
                vModelText,
                toxicThreshold.value,
                void 0,
                { number: true }
              ]
            ]),
            _cache[10] || (_cache[10] = createBaseVNode("p", { class: "help-text" }, "Au dessus de ce score, le message est banni.", -1))
          ]),
          createBaseVNode("div", _hoisted_11, [
            _cache[12] || (_cache[12] = createBaseVNode("label", null, "Action pour les messages Neutres", -1)),
            withDirectives(createBaseVNode("select", {
              "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => neutralAction.value = $event)
            }, [..._cache[11] || (_cache[11] = [
              createBaseVNode("option", { value: "highlight" }, "Mettre en évidence (Orange)", -1),
              createBaseVNode("option", { value: "hide" }, "Griser / Masquer partiellement", -1),
              createBaseVNode("option", { value: "ignore" }, "Ne rien faire", -1)
            ])], 512), [
              [vModelSelect, neutralAction.value]
            ])
          ])
        ]),
        _cache[22] || (_cache[22] = createBaseVNode("hr", { style: { "border": "0", "border-top": "1px solid #444", "margin": "30px 0" } }, null, -1)),
        createBaseVNode("div", _hoisted_12, [
          _cache[18] || (_cache[18] = createBaseVNode("h2", null, "🧠 Dataset IA (Entraînement)", -1)),
          _cache[19] || (_cache[19] = createBaseVNode("p", { class: "help" }, "Données récoltées manuellement pour entraîner le futur modèle personnalisé.", -1)),
          createBaseVNode("div", _hoisted_13, [
            createBaseVNode("div", _hoisted_14, [
              createBaseVNode("span", _hoisted_15, toDisplayString(datasetStats.value.total), 1),
              _cache[15] || (_cache[15] = createBaseVNode("span", { class: "stat-label" }, "Total Messages", -1))
            ]),
            createBaseVNode("div", _hoisted_16, [
              createBaseVNode("span", _hoisted_17, toDisplayString(datasetStats.value.clean), 1),
              _cache[16] || (_cache[16] = createBaseVNode("span", { class: "stat-label" }, "✅ Clean", -1))
            ]),
            createBaseVNode("div", _hoisted_18, [
              createBaseVNode("span", _hoisted_19, toDisplayString(datasetStats.value.toxic), 1),
              _cache[17] || (_cache[17] = createBaseVNode("span", { class: "stat-label" }, "❌ Toxic", -1))
            ])
          ]),
          createBaseVNode("div", _hoisted_20, [
            createBaseVNode("button", {
              onClick: downloadCsv,
              class: "btn-secondary",
              disabled: datasetStats.value.total === 0
            }, " 📥 Exporter le CSV ", 8, _hoisted_21),
            createBaseVNode("button", {
              onClick: triggerImport,
              class: "btn-secondary"
            }, " 📤 Importer un CSV "),
            createBaseVNode("input", {
              type: "file",
              ref_key: "importInput",
              ref: importInput,
              onChange: handleImport,
              accept: ".csv",
              style: { "display": "none" }
            }, null, 544),
            createBaseVNode("button", {
              onClick: refreshStats,
              class: "btn-secondary"
            }, " 🔄 Actualiser "),
            createBaseVNode("button", {
              onClick: clearDataset,
              class: "btn-danger",
              disabled: datasetStats.value.total === 0
            }, " 🗑️ Vider le Dataset ", 8, _hoisted_22)
          ]),
          datasetStats.value.total > 0 ? (openBlock(), createElementBlock("p", _hoisted_23, " Dernier ajout : " + toDisplayString(lastAdded.value), 1)) : createCommentVNode("", true)
        ])
      ]);
    };
  }
};
const Options = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-7d2496b8"]]);
createApp(Options).mount("#app");
//# sourceMappingURL=options.html-ed5899b3.js.map
